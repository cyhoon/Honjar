package com.example.std01.loginregistfunction;

import android.app.Application;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by std01 on 2017. 5. 13..
 */

public class Register extends AppCompatActivity {
    private String name;
    private String phoneNumber;
    private String password;
    private String confirmPassword;

    public final static String serv_url = "http://10.80.163.99/youngh/memberJoin.php";

    public Register(String name,String phoneNumber,String password,String confirmPassword){
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.password = password;
        this.confirmPassword = confirmPassword;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getConfirmPassword() {
        return confirmPassword;
    }

    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

   public boolean comparePassword(String password, String confirmPassword){
        if(password.equals(confirmPassword)) return true;
        else return false;
    }

    public boolean comparePasswordLength(String password){
        if(password.length() > 5)
            return true;
        else return false;
    }

    public boolean regiUser(final String name, final String phoneNumber, final String password){
        // 서버에서 값 받아와서 value 값이 있으면, true 반환, 값이 없으면 false 반환.
        Log.d("LOG_TAG3","sdada");
        StringRequest request = new StringRequest(Request.Method.POST, serv_url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {

                    JSONArray jsonArray = new JSONArray(response);
                    JSONObject jsonObject = jsonArray.getJSONObject(0);

                    String code = jsonObject.getString("code");

                    if(code.equals("reg_success"))
                    {
                        Toast.makeText(getApplicationContext(),"success",Toast.LENGTH_SHORT).show();
                        Log.d("LOG_TAG3","success");

                    }else{
                        Log.d("LOG_TAG3","faild");
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {

                Map<String,String> map = new HashMap<String,String>();
                map.put("user_id",phoneNumber);
                map.put("user_pw",password);
                map.put("user_name", name);

                return map;
            }
        };


        singleton.getInstance(this).addToRequest(request);


        return false;
    }

}
