package com.example.std01.loginregistfunction;

import android.app.Application;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

/**
 * Created by std01 on 2017. 5. 13..
 */

public class singleton extends AppCompatActivity{

    private static singleton instance;
    private RequestQueue req;
    private static Context cTx;


    private singleton(Context context)
    {
        cTx = context;
        req = getRequest();
    }

    private RequestQueue getRequest()
    {
        if(req == null){
            req = Volley.newRequestQueue(cTx.getApplicationContext());
        }
        return req;
    }

    public static singleton getInstance(Context context)
    {
        if(instance == null)
        {
            instance = new singleton(context);
        }
        return instance;
    }

    public<T> void addToRequest(Request<T> request)
    {
        req.add(request);
    }


}
