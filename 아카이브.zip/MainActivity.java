package com.example.std01.loginregistfunction;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    //private Button Login;
    private Button Regi;
    private EditText password;
    private EditText phoneNumber;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Login = (Button) findViewById(R.id.confirm);
        Regi = (Button) findViewById(R.id.register);
        //Login.setOnClickListener(this);
        Regi.setOnClickListener(this);

        password = (EditText) findViewById(R.id.phoneNumber_Input);
        phoneNumber = (EditText) findViewById(R.id.password_Input);

        Register regi = new Register("name","01047855602","qwerty","qwerty");

        if(regi.comparePasswordLength(regi.getPassword())){
            if(regi.regiUser(regi.getName(),regi.getPhoneNumber(),regi.getPassword()))
                Log.d("LOG_TAG1","회원가입 성공!");
            else Log.d("LOG_TAG1","해당 정보가 이미 있습나다.");
        } else{
            Log.d("LOG_TAG1","비밀번호 길이가 짧다!");
        }

        Login login = new Login("01047855602","qwerty");
        if(login.isAvailable(login.getPhoneNumber())){
            if(login.getPasswordFromServer(login.getPhoneNumber()).equals(login.getPassword()))
                Log.d("LOG_TAG2","비밀번호 일치됨!");
            else Log.d("LOG_TAG2","비밀번호 불일치");
        }

    }


    @Override
    public void onClick(View view) {
        int id = view.getId();

    }
}
