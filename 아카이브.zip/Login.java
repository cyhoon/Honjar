package com.example.std01.loginregistfunction;

/**
 * Created by std01 on 2017. 5. 13..
 */

public class Login {
    private String phoneNumber;
    private String password;
    public Login(String phoneNumber,String password){
        this.phoneNumber = phoneNumber;
        this.password = password;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getPassword() {
        return password;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPasswordFromServer(String phoneNumber){
        // select 해 와서 문자열 라턴
        return "qwerty";
    }

    public boolean compare(String baseString, String compareString){
        if(baseString.equals(compareString)) return true;
        else return false;
    }

    public boolean isAvailable(String value){
        // 서버에서 값 받아와서 value 값이 있으면, true 반환, 값이 없으면 false 반환.
        return true;
    }
}
