package dgsw.hs.kr.narsha1;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Debug;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.*;

import java.io.ByteArrayOutputStream;

public class MainActivity extends AppCompatActivity {

    JSONObject jsonObject = new JSONObject();

    ImageView imageView;
    TextView textView1;
    TextView textView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = new Intent(MainActivity.this, capsulePop.class);
        startActivity(intent);
        finish();

        imageView = (ImageView)this.findViewById(R.id.imageView1);
        textView1 = (TextView)this.findViewById(R.id.textView1);
        textView2 = (TextView)this.findViewById(R.id.textView2);

        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);

        int displaywidth =  metrics.widthPixels;
        int displayheight =  metrics.heightPixels;

        int width = displaywidth;
        int height = width / 2;

        imageView.getLayoutParams().width = width;
        imageView.getLayoutParams().height = height;

        Bitmap image = BitmapFactory.decodeResource(getResources(), R.drawable.image1);

        String stringFromBitmap = getStringFromBitmap(image);
        Bitmap bitmapFromString = getBitmapFromString(stringFromBitmap);

        createJSON(image, "2017년 5월 13일", "오늘 나는 여름 방학을 맞아 가족들과 함께 ㅇㅇㅇ 마을에 갔다.\n비록 비가 와서 많이 놀지는 못했지만 오랜만에 가족들과 시간을 보내 행복했다.\n다음엔 날씨가 좋은 날 다시 들러보고 싶다.");
        createView(jsonObject);
    }

    private String getStringFromBitmap(Bitmap bitmapPicture) {
        String encodedImage;
        ByteArrayOutputStream byteArrayBitmapStream = new ByteArrayOutputStream();
        bitmapPicture.compress(Bitmap.CompressFormat.PNG, 100, byteArrayBitmapStream);
        byte[] b = byteArrayBitmapStream.toByteArray();
        encodedImage = Base64.encodeToString(b, Base64.DEFAULT);

        return encodedImage;
    }

    private Bitmap getBitmapFromString(String jsonString) {
        byte[] decodedString = Base64.decode(jsonString, Base64.DEFAULT);
        Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
        return decodedByte;
    }

    public void createJSON(Bitmap bitmap, String text, String date) {
        String bitmapString = getStringFromBitmap(bitmap);

        try {
            jsonObject.put("text", text);
            jsonObject.put("image", bitmapString);
            jsonObject.put("date", date);
        } catch(JSONException e) {
            e.printStackTrace();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public void createView(JSONObject jsonObject) {
        String text = null;
        String image = null;
        String date = null;

        try {
            text = jsonObject.getString("text");
            image = jsonObject.getString("image");
            date = jsonObject.getString("date");
        } catch(JSONException e) {
            e.printStackTrace();
        }

        Bitmap bitmap = getBitmapFromString(image);

        imageView.setImageBitmap(bitmap);
        textView1.setText(text);
        textView2.setText(date);

    }
}
