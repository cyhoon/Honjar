package dgsw.hs.kr.narsha1;

import android.app.ActionBar;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class capsulePop extends AppCompatActivity {

    final int MAX_IMG = 10;

    Button select;
    TextView CNAME, CDATE, EXPIRE, CFRIEND;
    ImageView CIMAGE;
    Bitmap bitmap;

    //LinearLayout dynamic = (LinearLayout) findViewById(R.id.dynamic_friends);

    String[] imgArray = new String[MAX_IMG];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_capsule_pop);

        select = (Button) findViewById(R.id.select);

        CNAME = (TextView) findViewById(R.id.capsule_name);
        CDATE = (TextView) findViewById(R.id.create_date);
        EXPIRE = (TextView) findViewById(R.id.expire_date);
        CFRIEND = (TextView) findViewById(R.id.friends_list);
        CIMAGE = (ImageView) findViewById(R.id.image);

        select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                StringRequest request = new StringRequest(Request.Method.POST, SERVER.SERV_CAP_URL, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONArray array = new JSONArray(response);
                            JSONObject jobject = array.getJSONObject(0);

                            String c_name = jobject.getString("capsuleName");
                            String c_date = jobject.getString("capsuleDate");
                            String c_expire = jobject.getString("capsuleExpire");

                            final JSONArray c_friendsJSONArray = jobject.getJSONArray("friends");
                            final JSONArray c_mediaJSONArray = jobject.getJSONArray("mediaPath");

                            CNAME.setText(c_name);
                            CDATE.setText(c_date);
                            EXPIRE.setText(c_expire);

                            Thread mThread = new Thread() {

                                @Override
                                public void run() {

                                    try {
                                        //for(int i = 0; i < c_mediaJSONArray.length(); i++) {
                                            URL url = new URL(SERVER.SERV_ROOT_URL + c_mediaJSONArray.getJSONObject(0).getString("media" + /*i*/0));

                                            HttpURLConnection conn = (HttpURLConnection)url.openConnection();
                                            conn.setDoInput(true);
                                            conn.connect();

                                            InputStream is = conn.getInputStream();
                                            bitmap = BitmapFactory.decodeStream(is);

                                            //CIMAGE.setImageBitmap(bitmap);
                                        //}

                                        /*for(int i = 0; i < c_friendsJSONArray.length(); i++) {
                                            TextView friendTemp = new TextView(capsulePop.this);
                                            friendTemp.setText(c_friendsJSONArray.getJSONObject(i).getString("friend" + i));

                                            ((LinearLayout)findViewById(R.id.dynamic_friends)).addView(friendTemp);
                                        }*/
                                    } catch(IOException e) {
                                        e.printStackTrace();
                                    } catch(JSONException e) {
                                        e.printStackTrace();
                                    }
                                }
                            };

                            mThread.start();

                            try {
                                mThread.join();

                                CIMAGE.setImageBitmap(bitmap);
                            } catch(InterruptedException e) {
                                e.printStackTrace();
                            }

                            Toast.makeText(capsulePop.this, "success", Toast.LENGTH_SHORT).show();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                }){
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String,String> map = new HashMap<String, String>();
                        map.put("capsule_pk", "1");

                        return map;
                    }
                };

                singleton.getInstance(capsulePop.this).addToRequest(request);

            }
        });


    }
}
