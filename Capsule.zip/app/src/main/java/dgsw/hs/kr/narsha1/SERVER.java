package dgsw.hs.kr.narsha1;

/**
 * Created by Administrator on 2017-06-10.
 */
public interface SERVER {

    static final String SERV_ROOT_URL = "http://192.168.0.195/youngh/";

    static final String SERV_CAP_URL = SERV_ROOT_URL + "capsulePop.php";
    static final String SERV_FR_URL = SERV_ROOT_URL + "searchFriends.php";

}
