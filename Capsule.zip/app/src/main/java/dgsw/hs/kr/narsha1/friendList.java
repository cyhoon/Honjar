
package dgsw.hs.kr.narsha1;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

public class friendList extends AppCompatActivity {

    private ListView fr_listView;
    private ArrayAdapter<String> fr_adapter;

    private LinkedList<String> idList;
    private LinkedList<String> nameList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_capsule_pop);

        fr_adapter = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1);
        fr_listView = (ListView) findViewById(R.id.fr_listView);
        fr_listView.setAdapter(fr_adapter);
        fr_listView.setOnItemClickListener(onClickListItem);

                StringRequest request = new StringRequest(Request.Method.POST, SERVER.SERV_FR_URL, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONArray array = new JSONArray(response);

                            for(int i = 0; i < array.length(); i++) {
                                JSONObject jobject = array.getJSONObject(i);
                                fr_adapter.add(jobject.getString("user_id"));

                                idList.add(i, jobject.getString("user_id"));
                                nameList.add(i, jobject.getString("user_name"));
                            }

                            Toast.makeText(friendList.this, "success", Toast.LENGTH_SHORT).show();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                }){
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String,String> map = new HashMap<String, String>();
                        map.put("capsule_pk", "25");

                        return map;
                    }
                };

                singleton.getInstance(friendList.this).addToRequest(request);

            }

    private AdapterView.OnItemClickListener onClickListItem = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            Toast.makeText(getApplicationContext(), fr_adapter.getItem(position), Toast.LENGTH_SHORT).show();
        }
    };
}

